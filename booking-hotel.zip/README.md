# Hotel Booking System

## Background
- The system is meant for hotel to display her rooms for customer​ to view and book via a mobile application.

## Basic Requirements 
    • There is a content management system for the administrator to​ list/create/edit/delete rooms​comprising of type,​ description, image, quantity, and​​price.

    • To accommodate customers’​​mobile application, these APIs are needed
        ◦ API to list all the available rooms​ for​ any particular day in the future
        ◦ API to book multiple rooms​​for a number of days
        ◦ API to cancel any booking